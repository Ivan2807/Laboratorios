package com.example.laboratorio6

import android.R.attr.onClick
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButtonDefaults.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.laboratorio6.ui.theme.Laboratorio6Theme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Laboratorio6Theme {
                contadorl()
                }
            }
        }
    }

data class valores(
    val valor: Int,
    val incremento: Boolean)


@Preview(showBackground = true)
@Composable
fun contadorl(modifier: Modifier = Modifier) {
    var contador by remember { mutableStateOf(0) }
    var historial by remember { mutableStateOf(listOf<valores>()) }

    val incrementar ={
     contador++
        historial = historial + valores(contador, true)
    }
    val decrementar = {
        contador--
        historial = historial + valores(contador, false)
    }

    val reiniciar = {
        contador = 0
        historial = emptyList()
    }

    val totalIncrementos = historial.count { it.incremento }
    val totalDecrementos = historial.count { !it.incremento }
    val valorMaximo = if (historial.isNotEmpty()) historial.maxOf { it.valor } else 0
    val valorMinimo = if (historial.isNotEmpty()) historial.minOf { it.valor } else 0
    val totalCambios = historial.size
// Título
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {Text("Ivan Morataya")
        // Contador
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = decrementar,
                modifier = Modifier.size(50.dp)) { Text("-")}
            Text(
                text = contador.toString(),
                fontSize = 72.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(horizontal = 48.dp),
                textAlign = TextAlign.Center
            )
            Button(onClick = incrementar,
                modifier = Modifier.size(50.dp)) {Text("+") }


    }
// Estadísticas
        Column(
            modifier = Modifier.padding(50.dp),
        ) {
            EstadisticaRow("Total incrementos:", totalIncrementos.toString())
            EstadisticaRow("Total decrementos:", totalDecrementos.toString())
            EstadisticaRow("Valor máximo:", valorMaximo.toString())
            EstadisticaRow("Valor mínimo:", valorMinimo.toString())
            EstadisticaRow("Total cambios:", totalCambios.toString())
        }
        //historial
        Text(
            text = "Historial:")
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .padding(bottom = 24.dp)
        ) {
            items(historial) { movimiento ->
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color = if (movimiento.incremento) Color(0xFF059669) else Color(0xFFDC2626),
                            shape = RoundedCornerShape(6.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = movimiento.valor.toString(),
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Botón Reiniciar
        Button(
            onClick = reiniciar,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2563EB)
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = "Reiniciar",
                fontSize = 16.sp,
            )
        }}
}


@Composable
fun EstadisticaRow(etiqueta: String, valor: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = etiqueta,
            fontSize = 16.sp,
        )
        Text(
            text = valor,
            fontSize = 16.sp,
        )
    }
}


@Composable
fun ContadorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        content = content
    )
}